const enterButton = document.getElementById("enterButton")

document.getElementById("enterButton").addEventListener('click', function(){
    window.location.href = "tracking.html"
})